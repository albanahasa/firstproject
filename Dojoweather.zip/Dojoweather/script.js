function myFunction() {
    alert("Loading weather report...")
}

function deleteElement() {
    var elementToDelete = document.getElementById("delete");
    elementToDelete.remove();
}

function convertToFahrenheit(temp) {
    return Math.round(9 / 5 * temp + 32);
}

function convertToCelsius(temp) {
    return Math.round(5 / 9 * (temp - 32));
}

function convertToCF(element) {
    console.log(element.value);
    for (var i = 1; i < 9; i++) {
        var temperature = document.querySelector("#temp" + i);
        var value = parseInt(temperature.innerText);
        if (element.value == "°C") {
            temperature.innerText = convertToCelsius(value);
        } else {
            temperature.innerText = convertToFahrenheit(value);
        }
    }
}